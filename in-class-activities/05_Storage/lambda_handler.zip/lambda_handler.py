import random

def lambda_handler(event, context):
    # placeholder for large, compute-intensive summarization operation
    n_runs = 10**7
    sim = [random.random() for _ in range(n_runs)]
    summary = sum(sim) / n_runs

    # return result to participant
    return summary